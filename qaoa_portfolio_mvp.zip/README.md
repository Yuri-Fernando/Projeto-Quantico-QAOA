# Quantum Portfolio Optimization (QAOA) — MVP
Projeto simples e direto para demonstrar **otimização de portfólio** usando **QAOA (Qiskit)**, com comparação a um baseline clássico.
Foco: *mostrar entendimento prático* de tradução de um problema financeiro para **QUBO** e solução via **QAOA**.

## 🔧 Stack
- Python 3.10+
- qiskit, qiskit-optimization
- numpy, pandas, matplotlib (para gráficos simples)

## 📦 Setup (VSCode)
```bash
# 1) Crie e ative um venv
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
# source .venv/bin/activate

# 2) Instale dependências
pip install -r requirements.txt

# 3) Rode
python src/main.py --budget 2 --risk_aversion 0.5 --reps 2
```

> Dica: No VSCode, selecione o Python do venv (Command Palette → “Python: Select Interpreter”).

## 🧠 Formulação (resumo)
Maximizamos: **f(x) = μᵀx − λ·xᵀΣx**  
- x ∈ {0,1}ⁿ (seleção de ativos)
- μ: vetor de retorno esperado
- Σ: matriz de covariância (risco)
- λ: aversão ao risco (trade-off retorno vs risco)
- Restrição de orçamento: **∑ xᵢ = B** (B ativos selecionados). É aplicada via penalidade **P(∑xᵢ − B)²** no QUBO.

## 🏁 Objetivo do MVP
- Resolver uma instância pequena (3–6 ativos) com QAOA.
- Comparar com um baseline clássico por busca exaustiva.
- Mostrar **resultados reproduzíveis** e **código limpo**.

## 📂 Estrutura
```
qaoa_portfolio_mvp/
├── README.md
├── requirements.txt
└── src/
    ├── main.py
    └── qaoa_portfolio.py
```

## 📝 Pitch rápido (para follow-up)
- Problema: seleção ótima de ativos com trade-off retorno/risco e orçamento fixo.
- Abordagem: mapear para QUBO e resolver com QAOA (simulador), validando contra método clássico.
- Valor: demonstra a viabilidade de **prototipagem quântica aplicada** a casos financeiros do mundo real.
