"""
qaoa_portfolio.py
Ferramental para formular o problema de portfólio como QUBO e resolver via QAOA (Qiskit),
com baseline clássico por busca exaustiva.
"""
from __future__ import annotations
import itertools
from dataclasses import dataclass
from typing import List, Dict, Tuple

import numpy as np

# Qiskit imports
from qiskit import QuantumCircuit
from qiskit_aer import Aer
from qiskit.algorithms.minimum_eigensolvers import QAOA
from qiskit.primitives import Estimator
from qiskit_optimization import QuadraticProgram
from qiskit_optimization.algorithms import MinimumEigenOptimizer


@dataclass
class PortfolioInstance:
    tickers: List[str]
    mu: np.ndarray          # returns (n,)
    Sigma: np.ndarray       # covariance (n,n)
    budget: int             # number of assets to pick
    risk_aversion: float    # lambda


def build_quadratic_program(inst: PortfolioInstance, penalty: float = 4.0) -> QuadraticProgram:
    """
    Build QuadraticProgram for:  maximize mu^T x - lambda x^T Sigma x
    subject to sum x_i = budget, x_i in {0,1}
    Converted to minimization of -objective and budget handled via penalty in QUBO.

    We use a penalty term P (sum x_i - B)^2 folded into QUBO coefficients.
    """
    n = len(inst.tickers)
    mu = inst.mu.reshape(-1)
    Sigma = inst.Sigma
    lam = inst.risk_aversion
    B = inst.budget
    P = penalty

    # Objective to maximize -> we minimize its negative
    # f(x) = mu^T x - lam x^T Sigma x
    # Add penalty: P (sum x_i - B)^2 = P( sum x_i^2 + 2 sum_{i<j} x_i x_j - 2B sum x_i + B^2 )
    # As x_i^2 = x_i for binary, simplify terms into linear & quadratic contributions.
    Q = -(-2.0 * lam * Sigma.copy()) / 2.0  # placeholder; we will construct from scratch below

    # Start from zeros
    Q = np.zeros_like(Sigma, dtype=float)
    lin = np.zeros(n, dtype=float)
    const = 0.0

    # Base (to minimize): -mu^T x + lam x^T Sigma x
    lin += -mu
    Q += lam * Sigma  # note: contributes to 2*x_i x_j in quadratic form; QuadraticProgram expects symmetric Q

    # Penalty terms
    # (sum x_i - B)^2 = sum x_i + 2 sum_{i<j} x_i x_j - 2B sum x_i + B^2
    # Linear from penalty: P * (1 - 2B) * x_i  (since sum x_i appears with coefficient (1 - 2B))
    lin += P * (1.0 - 2.0 * B) * np.ones(n)
    # Quadratic from penalty: for i<j add 2P to Q_ij
    for i in range(n):
        for j in range(i + 1, n):
            Q[i, j] += 2.0 * P
            Q[j, i] += 2.0 * P  # keep symmetric

    const += P * (B ** 2)  # constant term (can be dropped; optimizer ignores constants)

    # Build QuadraticProgram
    qp = QuadraticProgram(name="quantum_portfolio")
    for i, t in enumerate(inst.tickers):
        qp.binary_var(name=f"x_{t}")
    # QuadraticProgram in Qiskit-Optimization expects: minimize 0.5 x^T Q x + c^T x + const
    qp.minimize(quadratic=Q, linear=lin, constant=const)
    return qp


def solve_qaoa(inst: PortfolioInstance, reps: int = 2, seed: int = 42) -> Dict:
    qp = build_quadratic_program(inst)
    backend = Aer.get_backend("aer_simulator_statevector")
    qaoa = QAOA(sampler=None, optimizer=None, reps=reps, seed=seed, estimator=Estimator())
    opt = MinimumEigenOptimizer(qaoa)
    result = opt.solve(qp)

    x = np.array([result.variables_dict[f"x_{t}"] for t in inst.tickers]).astype(int)
    value = -(inst.mu @ x - inst.risk_aversion * x.T @ inst.Sigma @ x)  # minimized value; report original objective separately
    objective = inst.mu @ x - inst.risk_aversion * x.T @ inst.Sigma @ x
    return {
        "x": x,
        "tickers_selected": [t for t, xi in zip(inst.tickers, x) if xi == 1],
        "objective": float(objective),
        "raw_min_value": float(value),
        "qaoa_reps": reps,
        "result": result
    }


def solve_classical_bruteforce(inst: PortfolioInstance) -> Dict:
    n = len(inst.tickers)
    best = None
    best_x = None
    for bits in itertools.product([0, 1], repeat=n):
        if sum(bits) != inst.budget:
            continue
        x = np.array(bits)
        obj = inst.mu @ x - inst.risk_aversion * x.T @ inst.Sigma @ x
        if (best is None) or (obj > best):
            best = obj
            best_x = x
    return {
        "x": best_x,
        "tickers_selected": [t for t, xi in zip(inst.tickers, best_x) if xi == 1],
        "objective": float(best),
    }


def demo_instance() -> PortfolioInstance:
    # Pequena instância sintética (4 ativos)
    tickers = ["PETR4", "VALE3", "ITUB4", "ABEV3"]
    # retornos esperados (mensais) fictícios
    mu = np.array([0.015, 0.012, 0.009, 0.008])
    # covariância fictícia (simétrica, PSD)
    Sigma = np.array([
        [0.040, 0.018, 0.012, 0.005],
        [0.018, 0.035, 0.010, 0.006],
        [0.012, 0.010, 0.030, 0.004],
        [0.005, 0.006, 0.004, 0.025],
    ])
    return PortfolioInstance(tickers=tickers, mu=mu, Sigma=Sigma, budget=2, risk_aversion=0.5)
