"""
main.py
Roteiro principal para rodar o QAOA e comparar com baseline clássico.
"""
import argparse
import numpy as np
from qaoa_portfolio import demo_instance, PortfolioInstance, solve_qaoa, solve_classical_bruteforce

def parse_args():
    p = argparse.ArgumentParser(description="QAOA Portfolio Optimization — MVP")
    p.add_argument("--budget", type=int, default=None, help="Número de ativos a selecionar (override do demo)")
    p.add_argument("--risk_aversion", type=float, default=None, help="Lambda (trade-off risco)")
    p.add_argument("--reps", type=int, default=2, help="Camadas do QAOA (reps)")
    return p.parse_args()

def main():
    args = parse_args()
    inst = demo_instance()
    if args.budget is not None:
        inst.budget = args.budget
    if args.risk_aversion is not None:
        inst.risk_aversion = args.risk_aversion

    print("=== Instância ===")
    print("Ativos:", inst.tickers)
    print("Retornos esperados (mu):", inst.mu)
    print("Covariância (Sigma):\n", inst.Sigma)
    print("Budget (B):", inst.budget, "| Lambda:", inst.risk_aversion)

    print("\n=== QAOA ===")
    qaoa_res = solve_qaoa(inst, reps=args.reps)
    print("Selecionados (QAOA):", qaoa_res["tickers_selected"])
    print("x* (QAOA):", qaoa_res["x"])
    print("Objetivo (QAOA):", qaoa_res["objective"])

    print("\n=== Clássico (brute-force) ===")
    classic_res = solve_classical_bruteforce(inst)
    print("Selecionados (clássico):", classic_res["tickers_selected"])
    print("x* (clássico):", classic_res["x"])
    print("Objetivo (clássico):", classic_res["objective"])

    # Nota rápida de comparação
    print("\nComparação:")
    print(f"Objetivo QAOA:    {qaoa_res['objective']:.6f}")
    print(f"Objetivo clássico:{classic_res['objective']:.6f}")
    print("Obs.: Em instâncias pequenas, o clássico costuma bater; a graça aqui é a **formulação QUBO** e a prova de conceito do QAOA.")

if __name__ == "__main__":
    main()
